package server;

public interface Pet {
	
	public String getName() ;
	public String getColor();
	public String getAge();
	public void setName(String name) ;
}
